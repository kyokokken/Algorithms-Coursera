/**
 * By convention, the indices i and j are integers between 1 and N, where (1, 1)
 * is the upper-left site: Throw a java.lang.IndexOutOfBoundsException if either
 * i or j is outside this range. The constructor should take time proportional
 * to N^2; all methods should take constant time plus a constant number of calls
 * to the union-find methods union(), find(), connected(), and count().
 */

public class Percolation {
	private boolean[][] open;
	private int N;
	private WeightedQuickUnionUF openUF;

	// create N-by-N grid, with all sites blocked
	public Percolation(int N) {
		open = new boolean[N][N];
		this.N = N;
		openUF = new WeightedQuickUnionUF(N * N);
	}

	// open site (row i, column j) if it is not already
	public void open(int i, int j) {
		// Exceptions
		if (i < 1 || j < 1 || i > N || j > N)
			throw new IndexOutOfBoundsException();

		open[i - 1][j - 1] = true;

		if (j > 1 && isOpen(i, j - 1)) // Se non siamo nel bordo
		{
			openUF.union(xyTo1D(i - 1, j - 1), xyTo1D(i - 1, j - 2));
		}
		if (j < N && isOpen(i, j + 1)) {
			openUF.union(xyTo1D(i - 1, j - 1), xyTo1D(i - 1, j));
		}
		if (i > 1 && isOpen(i - 1, j)) {
			openUF.union(xyTo1D(i - 1, j - 1), xyTo1D(i - 2, j - 1));
		}
		if (i < N && isOpen(i + 1, j)) {
			openUF.union(xyTo1D(i - 1, j - 1), xyTo1D(i, j - 1));
		}

	}

	private int xyTo1D(int i, int j) {
		return ((i * N) + (j % N));
	}

	// is site (row i, column j) open?
	public boolean isOpen(int i, int j) {
		// Exceptions
		if (i < 1 || j < 1 || i > N || j > N)
			throw new IndexOutOfBoundsException();
		return open[i - 1][j - 1];
	}

	// is site (row i, column j) full?
	public boolean isFull(int i, int j) {
		// Exceptions
		if (i < 1 || j < 1 || i > N || j > N)
			throw new IndexOutOfBoundsException();

		if (i == 1) {
			return open[i - 1][j - 1];
		}

		for (int firstRowElement = 0; firstRowElement < N; firstRowElement++)
//			if (open[i - 1][j - 1] && open[0][firstRowElement] && openUF
//					.connected(xyTo1D(i - 1, j - 1), firstRowElement)) {
			if (open[i - 1][j - 1] && open[0][firstRowElement]) {
				if (openUF.find(xyTo1D(i-1, j-1)) == openUF.find(firstRowElement))
					return true;
			}


		return false;
	}

	// does the system percolate?
	public boolean percolates() {
		
		for (int col = 1; col <= N; col++) {
			// isFull(N, col);
			
			if (isOpen(N, col) && isFull(N, col))
			{
				//System.out.println(openUF.find(xyTo1D(0, col-1)) + " " + openUF.find(xyTo1D(N-1, col-1)));
				return true;
			}
		}
		return false;
	}
}
 