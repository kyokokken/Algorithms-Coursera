/**
 * public class Deque<Item> implements Iterable<Item> {
   public Deque()                     // construct an empty deque
   public boolean isEmpty()           // is the deque empty?
   public int size()                  // return the number of items on the deque
   public void addFirst(Item item)    // insert the item at the front
   public void addLast(Item item)     // insert the item at the end
   public Item removeFirst()          // delete and return the item at the front
   public Item removeLast()           // delete and return the item at the end
   public Iterator<Item> iterator()   // return an iterator over items in order from front to end
}
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Deque<Item> implements Iterable<Item> {

//	private ArrayList<Item> items;
	private LinkedList<Item> front;
	private LinkedList<Item> back;

	public Deque() {
//		items = new ArrayList<Item>();
		front = new LinkedList<Item>();
		back = new LinkedList<Item>();
	}

	public boolean isEmpty() {
//		return items.isEmpty();
		return front.isEmpty() && back.isEmpty();
	}

	public int size() {
//		return items.size();
		return front.size() + back.size();
	}

	public void addFirst(Item item) {
		if (item == null)
			throw new NullPointerException();
//		items.add(0, item);
		front.add(item);
		
	}

	public void addLast(Item item) {
		if (item == null)
			throw new NullPointerException();
		back.add(item);
	}

	public Item removeFirst() {
		if (!front.isEmpty())
			return front.removeFirst();
		else if (!back.isEmpty())
			return back.removeLast();
		else
			throw new java.util.NoSuchElementException();
	}

	public Item removeLast() {
		if (!back.isEmpty())
			return back.removeFirst();
		else if (!front.isEmpty())
			return front.removeLast();
		else
			throw new java.util.NoSuchElementException();
	}

	public Iterator<Item> iterator() {
//		return items.iterator();
		throw new UnsupportedOperationException();
	}

}
